//
//  String-Extension.swift
//  VisionPro
//
//  Created by Alumno on 25/09/24.
//

import Foundation

extension String: Error, LocalizedError {
    
    public var errorDescription: String? { self }
    
}

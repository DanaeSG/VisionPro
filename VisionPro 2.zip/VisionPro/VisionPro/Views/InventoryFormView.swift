//
//  InventoryFormView.swift
//  VisionPro
//
//  Created by Alumno on 27/09/24.
//

import SwiftUI
import SafariServices
import UniformTypeIdentifiers
import USDZScanner

struct InventoryFormView: View {
    
    @State var vm = InventoryFormViewModel()
    @Environment(\.dismiss) var dismiss
    
    var body: some View {
        Form {
            List {
                inputSection
                arSection
                if case .deleting(let type) = vm.loadingState {
                    HStack{
                        Spacer()
                        VStack(spacing: 8) {
                            ProgressView()
                            Text("Deleting \(type == .usdzWithThumbnail ? "USDZ file": "Item")")
                                .foregroundStyle(.red)
                        }
                        Spacer()
                    }
                }
                
                if case .edit = vm.formType {
                    Button("Delete", role: .destructive) {
                        Task {
                            do {
                                try await vm.deleteItem()
                                dismiss()
                            } catch {
                                vm.error = error.localizedDescription
                            }
                        }
                    }
                }
            }
        }
        .toolbar {
            ToolbarItem(placement: .cancellationAction) {
                Button("Cancel") {
                    dismiss()
                }
                .disabled(vm.loadingState != .none)
            }
            
            ToolbarItem(placement: .confirmationAction) {
                Button("Save") {
                    do {
                        try vm.save()
                        dismiss()
                    } catch {}
                }
                .disabled(vm.loadingState != .none || vm.name.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty)
            }
        }
        .confirmationDialog("Add USDZ", isPresented: $vm.showUSDZSource, titleVisibility: .visible, actions: { Button("Select file") {
            vm.selectedUSDZSource = .objectCapture
        }
            Button("Object Capture") {
                vm.selectedUSDZSource = .objectCapture
            }
        })
        .sheet(isPresented: .init(get: {vm.selectedUSDZSource == .objectCapture}, set: { _ in vm.selectedUSDZSource = nil }), content: { USDZScanner { url in Task {await vm.uploadUSDZ(fileURL: url) }
            vm.selectedUSDZSource = nil }
        })
        .fileImporter(isPresented: .init(get: { vm.selectedUSDZSource == .fileImporter }, set: { _ in vm.selectedUSDZSource = nil }), allowedContentTypes: [UTType.usdz], onCompletion: { result in
            switch result {
            case .success(let url):
                Task { await vm.uploadUSDZ(fileURL: url, isSecurityScopedResource: true) }
            case .failure(let failure):
                vm.error = failure.localizedDescription
            }})
        .alert(isPresented: .init(get: { vm.error != nil }, set: { _ in vm.error = nil }), error: "An error has ocurred", actions: { _ in }, message: { _ in Text(vm.error ?? "" )
        })
        .navigationTitle(vm.navigationTitle)
        .navigationBarTitleDisplayMode(.inline)
    }
    
    var inputSection: some View {
        Section {
            TextField("Name", text: $vm.name)
            Stepper("Quantity: \(vm.quantity)", value: $vm.quantity)
        }
        .disabled(vm.loadingState != .none)
    }
    
    var arSection: some View {
        Section("AR Model") {
            if let thumbnailURL = vm.thumbnailURL {
                AsyncImage(url: s)
            }
        }
    }
        
        
        actions: <#T##() -> View#>)
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    InventoryFormView()
}

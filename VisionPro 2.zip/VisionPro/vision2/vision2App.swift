//
//  vision2App.swift
//  vision2
//
//  Created by Alumno on 25/09/24.
//

import SwiftUI

@main
struct vision2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

//
//  InventoryItem.swift
//  VisionPro
//
//  Created by Alumno on 25/09/24.
//

import Foundation
import FirebaseFirestore

public struct InventoryItem: Identifiable, Codable, Equatable {
    public var id = UUID().uuidString
    
    // Timestamps de subida y actualizacion definidas por el servidor
    @ServerTimestamp
    var createdAt: Date?
    
    @ServerTimestamp
    var updatedAt: Date?
    
    var name: String
    var quantity: Int
    
    var usdzLink: String?
    
    // computed variable para convertir a usdzlINK A UNA url VALIDA
    var usdzURL: URL? {
        // Revisas que la propiedad de link no sea nula
        guard let usdzLink else { return nil }
        
        return URL(string: usdzLink)
    }
    
    // QuickLook framework para crear thumbnails de 300 x 300 en base al archivo usdz
    var thumbnailLink: String?
    
    // Computed variable para convertir a thumbnailLink a una URL valida
    var thumbnailURL: URL? {
        guard let thumbnailLink else { return nil}
        
        return URL(string: thumbnailLink)
    }
    
}

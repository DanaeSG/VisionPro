//
//  InventoryFormViewModel.swift
//  VisionPro
//
//  Created by Alumno on 25/09/24.
//

import Foundation
import FirebaseFirestore
import FirebaseStorage
import SwiftUI
import QuickLookThumbnailing

@Observable
class InventoryFormViewModel{
    let db = Firestore.firestore()
    let formType: FormType
    
    let id: String
    var name = ""
    var quantity = 0
    var usdzURL: URL?
    var thumbnailURL: URL?
    
    var loadingState = LoadingType.none
    var error: String?
    
    var uploadProgress: UploadProgress?
    var showUSDZSource = false
    var selectedUSDZSource: USDZSourceType?
    
    let byteCountFormatter: ByteCountFormatter = {
        let f = ByteCountFormatter()
        f.countStyle = .file
        return f
    }()
    
    var navigationTitle: String {
        switch formType {
        case .add:
            return "Add Item"
        case .edit: 
            return "Edit Item"
        }
        }
    
    init(formType: FormType = .add) {
        self.formType = formType
        switch formType {
        case .add:
            id = UUID().uuidString
        case .edit(let item):
            id = item.id
            name = item.name
            quantity = item.quantity
            if let uzdzURL =item.usdzURL {
                self.usdzURL = usdzURL
            }
            if let thumbnailURL = item.thumbnailURL{
                self.thumbnailURL = thumbnailURL
            }
        }
    }
    
    func save() throws {
        loadingState = .savingItem
        
        defer { loadingState = .none }
        
        var item: InventoryItem
        switch formType {
        case .add:
            item = .init(id: id, name: name, quantity: quantity)
        case .edit(let inventoryItem):
            item = inventoryItem
            item.name = name
            item.quantity = quantity
        }
        item.usdzLink = usdzURL?.absoluteString
        item.thumbnailLink = thumbnailURL?.absoluteString
        
        do {
            try db.document("items/\(item.id)")
                .setData(from: item)
        } catch {
            self.error = error.localizedDescription
            throw error
        }
    }
    
    @MainActor
    func deleteUSDZ() async {
        let storageRef = Storage.storage().reference()
        let usdzRef = storageRef.child("\(id).usdz")
        let thumbnailRef = storageRef.child("\(id).jpg")
    }
}

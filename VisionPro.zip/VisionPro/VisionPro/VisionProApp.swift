//
//  VisionProApp.swift
//  VisionPro
//
//  Created by Alumno on 25/09/24.
//

import SwiftUI

@main
struct VisionProApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
